import add from "./add";
import deletePermission from "./delete";
import deleteByIds from "./deleteByIds";
import listByAllowance from "./list";

export { add, deletePermission, deleteByIds, listByAllowance };
