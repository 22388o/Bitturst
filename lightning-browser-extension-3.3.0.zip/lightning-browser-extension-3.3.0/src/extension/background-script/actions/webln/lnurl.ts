import lnurl from "../lnurl";

/*
For now this is simple an alias for ../lnurl
But this function is called from webln. We can add certain permissions here later
*/

export default lnurl;
