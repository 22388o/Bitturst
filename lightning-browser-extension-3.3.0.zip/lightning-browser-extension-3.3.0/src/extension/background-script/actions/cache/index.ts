import getCurrencyRate from "./getCurrencyRate";

export { getCurrencyRate };
