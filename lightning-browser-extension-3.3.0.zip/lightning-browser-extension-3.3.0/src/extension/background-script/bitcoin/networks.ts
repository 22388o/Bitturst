import { Network, networks } from "bitcoinjs-lib";
export { Network, networks };
