// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare type FixMe = any;

declare module "*.svg" {
  const content: string;
  export default content;
}

declare module "*.png" {
  const content: string;
  export default content;
}

declare module "*.jpg" {
  const content: string;
  export default content;
}
