function MenuDivider() {
  return <hr className="my-1 dark:border-white/10" />;
}

export default MenuDivider;
