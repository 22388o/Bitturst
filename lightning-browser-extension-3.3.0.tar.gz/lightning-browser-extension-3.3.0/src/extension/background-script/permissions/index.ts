import { addPermissionFor } from "./addPermissionFor";
import { hasPermissionFor } from "./hasPermissionFor";

export { addPermissionFor, hasPermissionFor };
