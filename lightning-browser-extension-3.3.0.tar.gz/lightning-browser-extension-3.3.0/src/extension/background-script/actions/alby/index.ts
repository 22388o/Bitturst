import enable from "./enable";
import isEnabled from "./isEnabled";
export { enable, isEnabled };
